package net.lrivas.miagenda.clases;

public class Configuraciones {
    public String urlWebServices;

    public Configuraciones(){
        this.urlWebServices = "http://192.168.1.72/ws_app/webservice02.php";
    }
}
